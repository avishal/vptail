<?php

use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\grid\GridView;
use common\models\Classes;
use common\models\Subjects;
use common\models\SubjectChapters;

/* @var $this yii\web\View */
/* @var $searchModel common\models\VideosSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Videos';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="videos-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Videos', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            //'classid',
            //'subjid',
            //'chapterid',
            [
                'attribute'=>'classid',
                'filter'=>Html::activeDropDownList($searchModel, 'classid', ArrayHelper::map(Classes::find()->all(),'id','title'),['class'=>'form-control','prompt' => 'All']),
                'value'=> function($model)
                {
                    return $model->class ? $model->class->title : 'not set';
                }
            ],
            [
                'attribute'=>'subjid',
                'filter'=>Html::activeDropDownList($searchModel, 'subjid', ArrayHelper::map(Subjects::find()->all(),'id','title'),['class'=>'form-control','prompt' => 'All']),
                'value'=> function($model)
                {
                    return $model->subj ? $model->subj->title : 'not set';
                }
            ],
            [
                'attribute'=>'chapterid',
                'filter'=>Html::activeDropDownList($searchModel, 'chapterid', ArrayHelper::map(SubjectChapters::find()->all(),'id','title'),['class'=>'form-control','prompt' => 'All']),
                'value'=> function($model)
                {
                    return $model->chapter->title;
                }
            ],
            
            'title',
            'url',
            'isfree',
            'status',
            // 'created',
            // 'updated',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>

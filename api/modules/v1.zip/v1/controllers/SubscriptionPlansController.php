<?php

namespace api\modules\v1\controllers;

use Yii;
use yii\rest\ActiveController;
use yii\data\ActiveDataProvider;
use common\models\Students;
use common\models\Subjects;
use common\models\Classes;
use common\models\Videos;
use common\models\SubscriptionPlans;
use common\models\SubscriptionVideos;
use common\models\StudentSubscription;


class SubscriptionPlansController extends ActiveController
{
	public $modelClass = 'common\models\SubscriptionPlans';
}